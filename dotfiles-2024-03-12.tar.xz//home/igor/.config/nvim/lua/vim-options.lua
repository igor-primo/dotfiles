local vim = vim
local Plug = vim.fn['plug#']

vim.cmd("set expandtab")
vim.cmd("set tabstop=2")
vim.cmd("set softtabstop=2")
vim.cmd("set shiftwidth=2")

vim.call('plug#begin')
Plug('neoclide/coc.nvim', { ['branch'] = 'master', ['do'] = 'npm ci'})
Plug 'nvim-lua/plenary.nvim'
vim.call('plug#end')
