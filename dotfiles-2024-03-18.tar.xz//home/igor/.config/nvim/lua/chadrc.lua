local M = {}

M.ui = {
  changed_themes = {
    gruvbox_light = {
      base16 = {
      }
    }
  },
  theme = "gruvbox_light",
}

return M
