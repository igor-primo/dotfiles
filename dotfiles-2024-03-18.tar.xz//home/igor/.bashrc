# .bashrc

# Source global definitions

if [ -f /etc/bashrc ]; 
then        
    . /etc/bashrc 
fi

# User specific environment

if ! [[ "$PATH" =~ "$HOME/.local/bin:$HOME/bin:" ]] 
then    
      PATH="$HOME/.local/bin:$HOME/bin:$PATH" 
fi 

export PATH

# Uncomment the following line if you don't like systemctl's auto-paging feature:

# export SYSTEMD_PAGER=

# User specific aliases and functions

if [ -d ~/.bashrc.d ]; then        
          for rc in ~/.bashrc.d/*; do                
              if [ -f "$rc" ]; then                        
                   . "$rc"                
              fi        
         done fi 
unset rc

alias mpv="mpv --ytdl-raw-options=format=best "
alias howmanyhosts="while true;do nmap -sP 192.168.1.1/24 | grep \"Nmap done\" | awk '{print $6}' | tr -d '('; sleep 2;done"
alias tmux="/usr/local/bin/tmux"
alias ls="eza --long -T -L 1 -g -m -n --icons"

PATH="/home/igor/perl5/bin${PATH:+:${PATH}}"; export PATH;
PERL5LIB="/home/igor/perl5/lib/perl5${PERL5LIB:+:${PERL5LIB}}"; export PERL5LIB;
PERL_LOCAL_LIB_ROOT="/home/igor/perl5${PERL_LOCAL_LIB_ROOT:+:${PERL_LOCAL_LIB_ROOT}}"; export PERL_LOCAL_LIB_ROOT;
PERL_MB_OPT="--install_base \"/home/igor/perl5\""; export PERL_MB_OPT;
PERL_MM_OPT="INSTALL_BASE=/home/igor/perl5"; export PERL_MM_OPT;

. "$HOME/.cargo/env"

if [[ -z $DISPLAY ]] && [[ $(tty) = /dev/tty1 ]]; then
	startx
fi

# Base16 Shell
BASE16_SHELL="$HOME/.config/base16-shell/"
[ -n "$PS1" ] && \
    [ -s "$BASE16_SHELL/profile_helper.sh" ] && \
        source "$BASE16_SHELL/profile_helper.sh"
  
# [ $(date +%H) -gt 18 ]
base16_gruvbox-dark-hard 

export EDITOR=nvim
export PATH=$PATH:/home/igor/scripts
export BASE16_TMUX_OPTION_STATUSBAR=1
export FZF_DEFAULT_OPTS="
  -m --height 60% --reverse --walker-skip .*"
export FZF_CTRL_R_OPTS="
  --preview 'echo {}' --preview-window up:3:hidden:wrap
  --bind 'ctrl-/:toggle-preview'
  --bind 'ctrl-y:execute-silent(echo -n {2..} | pbcopy)+abort'
  --color header:italic
  --header 'Press CTRL-Y to copy command into clipboard'"
export FZF_ALT_C_OPTS="
  --walker-skip .git,node_modules,target
  --preview 'tree -C {}'"

[ -f ~/.fzf.bash ] && source ~/.fzf.bash

fman() {
    man -k . | fzf -q "$1" --prompt='man> '  --preview $'echo {} | tr -d \'()\' | awk \'{printf "%s ", $2} {print $1}\' | xargs -r man | col -bx | bat -l man -p --color always' | tr -d '()' | awk '{printf "%s ", $2} {print $1}' | xargs -r man
}
# Get the colors in the opened man page itself
export MANPAGER="sh -c 'col -bx | bat -l man -p --paging always'"
