(require 'package)
(add-to-list 'package-archives '("melpa" . "https://melpa.org/packages/"))
(package-initialize)
(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(ansi-color-faces-vector
   [default default default italic underline success warning error])
 '(ansi-color-names-vector
   ["black" "red3" "ForestGreen" "yellow3" "blue" "magenta3" "DeepSkyBlue" "gray50"])
 '(column-number-mode t)
 '(custom-enabled-themes '(wombat))
 '(debug-on-error t)
 '(display-battery-mode t)
 '(display-line-numbers-type 'visual)
 '(display-time-mode t)
 '(fringe-mode 0 nil (fringe))
 '(org-babel-load-languages
   '((python . t)
	 (emacs-lisp . t)
	 (R . t)
	 (C . t)
	 (shell . t)))
 '(org-confirm-babel-evaluate nil)
 '(package-selected-packages
   '(yaml-mode ob-async ggtags cdlatex auctex haskell-mode use-package company-coq proof-general powershell magit org-drill nhexl-mode helm-mode-manager lsp-javacomp lsp-ui tree-sitter-langs tree-sitter typescript-mode javascript-mode dap-mode vterm-toggle org-agenda-property vterm helm-open-github evil ##))
 '(scroll-bar-mode nil)
 '(size-indication-mode t)
 '(tool-bar-mode nil)
 '(tool-bar-position 'bottom)
 '(warning-suppress-log-types '((comp)))
 '(warning-suppress-types '((org-babel))))
(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(default ((t (:family "Noto Sans Mono" :foundry "GOOG" :slant normal :weight normal :height 75 :width normal)))))
 (require 'evil)
 (evil-mode 1)

(global-set-key (kbd "C-x C-b") 'ibuffer)

(setq package-selected-packages '(lsp-mode yasnippet lsp-treemacs helm-lsp
    projectile hydra flycheck company avy which-key helm-xref dap-mode))

(when (cl-find-if-not #'package-installed-p package-selected-packages)
  (package-refresh-contents)
  (mapc #'package-install package-selected-packages))

(menu-bar-mode -1) 

(setq ido-enable-flex-matching t)
(setq ido-everywhere t)
(ido-mode 1)

(which-key-mode)
(add-hook 'js-mode-hook 'lsp)
(add-hook 'ts-mode-hook 'lsp)
(add-hook 'rust-mode-hook 'lsp)
(add-hook 'tex-mode-hook 'lsp)
(add-hook 'python-mode-hook 'lsp)
(add-hook 'c-mode-common-hook
		  (lambda ()
			(when (derived-mode-p 'c-mode 'c++-mode 'java-mode 'asm-mode)
	(ggtags-mode 1))))
(add-hook 'dired-mode-hook 'ggtags-mode)

(with-eval-after-load 'lsp-mode
  (add-hook 'lsp-mode-hook #'lsp-enable-which-key-integration)
  (yas-global-mode))

(setq scroll-margin 0
      scroll-conservatively 100000
      scroll-preserve-screen-position 1)

(setq-default tab-width 4)
(setq indent-line-function 'insert-tab)

(setenv "TZ" "UTC+03:00")

(evil-set-initial-state 'term-mode 'emacs)
(evil-set-initial-state 'vterm-mode 'emacs)
(evil-set-initial-state 'dired-mode 'emacs)

;; @see https://bitbucket.org/lyro/evil/issue/511/let-certain-minor-modes-key-bindings
(eval-after-load 'ggtags
  '(progn
     (evil-make-overriding-map ggtags-mode-map 'normal)
     ;; force update evil keymaps after ggtags-mode loaded
     (add-hook 'ggtags-mode-hook #'evil-normalize-keymaps)))
