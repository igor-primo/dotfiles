#/bin/bash

MAPPERNAME="crypt"
MOUNTPATH="/mnt/$MAPPERNAME"

sudo umount $MOUNTPATH && \
	sudo cryptsetup luksClose $MAPPERNAME
