#!/bin/sh

setxkbmap br
setxkbmap -option ctrl:swapcaps
/usr/bin/xset r rate 250 60
