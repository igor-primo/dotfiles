#/bin/sh

if [ "$1" == "" ]
then
	exit 1
fi

while true;
do
	sleep "$1"
	notify-send "Countdown finished" >/dev/null
done
