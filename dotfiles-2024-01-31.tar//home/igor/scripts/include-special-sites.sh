#/bin/bash

doas bash -c "echo '0.0.0.0 www.youtube.com' >> /etc/hosts"
doas bash -c "echo '0.0.0.0 www.newadvent.org' >> /etc/hosts"
