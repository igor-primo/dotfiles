#/bin/sh

if [ "$1" == "-h" -o "$1" == "--help" -o "$1" == "" -o "$2" == "" ];then
   echo "Usage: back.sh <src> <dstname>"
   echo "Example: back.sh . /mnt/crypt/shit"
   echo "It will create a file like /mnt/crypt/shit"
   echo "This script uses tar"
   exit 0
fi
   
tar cf "$2-$(date +%F).tar" "$1"



