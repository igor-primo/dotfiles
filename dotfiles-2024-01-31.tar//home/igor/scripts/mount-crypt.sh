#/bin/bash

MAPPERNAME="crypt"
MOUNTPATH="/mnt/$MAPPERNAME"

sudo cryptsetup luksOpen /dev/"$1" $MAPPERNAME && \
	mkdir -p $MOUNTPATH >/dev/null && \
	sudo mount /dev/mapper/$MAPPERNAME $MOUNTPATH
									
