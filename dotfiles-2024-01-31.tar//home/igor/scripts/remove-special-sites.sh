#/bin/sh

doas bash -c "sed -i '/0\.0\.0\.0 www.youtube\.com/d' /etc/hosts"
doas bash -c "sed -i '/0\.0\.0\.0 www.newadvent\.org/d' /etc/hosts"
