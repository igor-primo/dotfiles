return {
  "nvim-treesitter/nvim-treesitter",
  build = ":TSUpdate",
  config = function()
    local configs = require("nvim-treesitter.configs")
    configs.setup({
      auto_isntall = true,
      ensure_installed = {
        "lua",
        "javascript",
        "typescript",
        "c",
        "bash",
        "html",
        "json",
        "tsx",
        "yaml"
      },
      highlight = { enable = true },
      indent = { enable = true }
    })
  end
}
