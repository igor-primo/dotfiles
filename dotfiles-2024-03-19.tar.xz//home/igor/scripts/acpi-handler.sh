#/bin/bash

while true;
do
	_percent=$(acpi | awk '{print $4}' | tr -d '[,%]')
	_status=$(acpi | awk '{print $3}' | tr -d ',')
	if [[ "$_percent" -lt 20 && "$_status" == "Discharging" ]];
	then
		notify-send "Battery $_percent%"
	fi
	sleep 20
done
