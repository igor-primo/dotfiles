#/bin/sh

emacsclient -c --frame-parameters="((internal-border-width . 30))"
