#/bin/bash

while true;
do
	_hour=$(date +%H)
	feh --bg-fill "/home/igor/.bg/$_hour.jpg" || \
		feh --bg-fill /home/igor/bg.jpg
	sleep 900
done
