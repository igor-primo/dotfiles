#/bin/sh

while true;
do
	notify-send "$(date +%c)"
	sleep 1800
done
