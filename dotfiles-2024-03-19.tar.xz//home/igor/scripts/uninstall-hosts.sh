#/bin/sh

cat <<EOF > oldhosts
# Loopback entries; do not change.
# For historical reasons, localhost precedes localhost.localdomain:
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
# See hosts(5) for proper format and other examples:
# 192.168.1.10 foo.mydomain.org foo
# 192.168.1.13 bar.mydomain.org bar

0.0.0.0 www.newadvent.org
EOF

doas bash -c "cat ./oldhosts > /etc/hosts"
rm ./oldhosts
