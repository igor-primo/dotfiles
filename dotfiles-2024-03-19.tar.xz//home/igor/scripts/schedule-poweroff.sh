#/bin/sh

_seconds="$1"

sleep $_seconds && \
	poweroff
