#/bin/bash

while true;
do
	_date=$(date +%c)
	notify-send "$_date"
	sleep 900
done
