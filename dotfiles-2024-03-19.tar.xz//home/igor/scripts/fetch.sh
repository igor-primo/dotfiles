#/bin/sh

# Programs:
# dunst
# 2bwm
# emacs
# rofi
# picom

_destfile="/home/$USER/dotfiles.tar"

# Configs
_arr=("/home/$USER/.config/dunst/dunstrc")
_arr+=("/home/$USER/.config/rofi/config.rasi")
_arr+=("/home/$USER/repos/2bwm/config.h")
_arr+=("/home/$USER/.picom.conf")
_arr+=("/home/$USER/.emacs.d/init.el")
_arr+=("/home/$USER/.xinitrc")

# Bins
_arr+=("/home/$USER/bg.jpg")

# Scripts
_arr+=($(find /home/$USER/scripts))

tar cvPf $_destfile ${_arr[@]}
