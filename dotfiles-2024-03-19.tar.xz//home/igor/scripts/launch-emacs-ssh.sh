
#/bin/sh

_flag1=$1
_client=$2
_host=$3
_flag2=$4
_port=$5

echo $_client
echo $_host

_program="/bin/bash -c \"$_client $_host\""

echo $_program

emacsclient -c -e "(ansi-term \"$_program\")"
