#/bin/bash

while true;
do
	# fetch data
	_battery=$(acpi | grep "Battery 0" | awk '{print $4}' | tr -d '[,%]')
	_batstatus=$(acpi grep "Battery 0" | awk '{print $3}' | tr -d ,)
	_lanip=$(ip add | grep wlp2s0 | grep inet | awk '{print $2}')
	_usedmem=$(free -h | grep Mem | awk '{print $3}')
	_availablemem=$(free -h | grep Mem | awk '{print $7}')
  _cpuusage=$(lscpu | grep scaling | awk '{print $4}')
  _cputemp=$(sensors | grep temp1 | awk '{print $2}')

	# send occasional conditional actions
	if [[ $_battery == "" ]];
	then
		_battery="No battery here, so read a lonely"
	fi
	
	if [[ "$_battery" -lt 20 && "$_batstatus" == "Discharging" ]];
	then
		notify-send -u critical "Battery $_battery%"
	fi

	if [[ $_lanip == "" ]];
	then
		_lanip=$(ip add | grep enp0s31f6 | grep inet | awk '{print $2}')
	fi

	# show to the bar
  echo "Battery: $_battery % | IP: $_lanip | Used Mem: $_usedmem | Available Mem: $_availablemem | CPU usage: $_cpuusage (MHz) | CPU temp: $_cputemp"
	sleep 15
done
