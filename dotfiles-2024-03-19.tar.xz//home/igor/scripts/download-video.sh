#/bin/bash

_url="$1"

yt-dlp --wait-for-video 15-20 -f 137 $_url #>> $HOME/scripts/ytdlp-$(date +%F).txt
