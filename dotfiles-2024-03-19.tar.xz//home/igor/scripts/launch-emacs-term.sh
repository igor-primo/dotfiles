#/bin/sh

emacsclient -c -e '(ansi-term "bash")'
