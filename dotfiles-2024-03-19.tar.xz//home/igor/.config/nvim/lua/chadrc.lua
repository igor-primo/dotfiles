local M = {}

M.ui = {
  changed_themes = {
    gruvchad = {
      base16 = {
      }
    }
  },
  theme = "gruvchad",
}

return M
