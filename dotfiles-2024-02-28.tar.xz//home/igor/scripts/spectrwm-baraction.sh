#/bin/bash

while true;
do
	# fetch data
	_battery=$(acpi | grep "Battery 0" | awk '{print $4}' | tr -d '[,%]')
	_batstatus=$(acpi grep "Battery 0" | awk '{print $3}' | td -d ,)
	_lanip=$(ip add | grep wlp2s0 | grep inet | awk '{print $2}')
	_usedmem=$(free -h | grep Mem | awk '{print $3}')
	_availablemem=$(free -h | grep Mem | awk '{print $7}')

	# send occasional notifications
	if [[ "$_battery" -lt 20 && "$_batstatus" == "Discharging" ]];
	then
		notify-send "Battery $_percent%"
	fi

	echo "Battery: $_battery % | IP: $_lanip | Used Mem: $_usedmem | Available Mem: $_availablemem"
	sleep 10
done
